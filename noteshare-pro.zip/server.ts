import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import multer from "multer";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import Database from "better-sqlite3";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("database.sqlite");
const JWT_SECRET = process.env.JWT_SECRET || "super-secret-key";

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'student',
    profile_picture TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    subject TEXT NOT NULL,
    tags TEXT,
    file_path TEXT NOT NULL,
    uploader_id INTEGER,
    downloads INTEGER DEFAULT 0,
    rating_sum INTEGER DEFAULT 0,
    rating_count INTEGER DEFAULT 0,
    is_approved INTEGER DEFAULT 0,
    ai_summary TEXT,
    ai_keywords TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploader_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS bookmarks (
    user_id INTEGER,
    note_id INTEGER,
    PRIMARY KEY (user_id, note_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (note_id) REFERENCES notes(id)
  );

  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    note_id INTEGER,
    text TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (note_id) REFERENCES notes(id)
  );
`);

const app = express();
app.use(express.json());

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}
app.use("/uploads", express.static(uploadsDir));

// Multer Config
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname),
});
const upload = multer({ storage });

// Middleware: Auth
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// --- AUTH ROUTES ---
app.post("/api/register", async (req, res) => {
  const { name, email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  try {
    const info = db.prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)").run(name, email, hashedPassword);
    res.status(201).json({ id: info.lastInsertRowid });
  } catch (e) {
    res.status(400).json({ error: "Email already exists" });
  }
});

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const user: any = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, JWT_SECRET);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

// --- NOTES ROUTES ---
app.post("/api/notes", authenticateToken, upload.single("file"), (req: any, res) => {
  const { title, description, subject, tags } = req.body;
  const filePath = req.file.path;
  const uploaderId = req.user.id;

  const info = db.prepare(`
    INSERT INTO notes (title, description, subject, tags, file_path, uploader_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(title, description, subject, tags, filePath, uploaderId);

  res.status(201).json({ id: info.lastInsertRowid });
});

app.get("/api/notes", (req, res) => {
  const { subject, search, sort } = req.query;
  let query = "SELECT notes.*, users.name as uploader_name FROM notes JOIN users ON notes.uploader_id = users.id WHERE is_approved = 1";
  const params: any[] = [];

  if (subject) {
    query += " AND subject = ?";
    params.push(subject);
  }
  if (search) {
    query += " AND (title LIKE ? OR description LIKE ?)";
    params.push(`%${search}%`, `%${search}%`);
  }

  if (sort === "popular") query += " ORDER BY downloads DESC";
  else if (sort === "rated") query += " ORDER BY (rating_sum/NULLIF(rating_count, 0)) DESC";
  else query += " ORDER BY created_at DESC";

  const notes = db.prepare(query).all(...params);
  res.json(notes);
});

app.get("/api/notes/:id", (req, res) => {
  const note = db.prepare(`
    SELECT notes.*, users.name as uploader_name 
    FROM notes 
    JOIN users ON notes.uploader_id = users.id 
    WHERE notes.id = ?
  `).get(req.params.id);
  
  if (!note) return res.status(404).json({ error: "Note not found" });
  
  const comments = db.prepare(`
    SELECT comments.*, users.name as user_name 
    FROM comments 
    JOIN users ON comments.user_id = users.id 
    WHERE note_id = ? 
    ORDER BY created_at DESC
  `).all(req.params.id);

  res.json({ ...note, comments });
});

app.post("/api/notes/:id/download", (req, res) => {
  db.prepare("UPDATE notes SET downloads = downloads + 1 WHERE id = ?").run(req.params.id);
  res.sendStatus(200);
});

app.post("/api/notes/:id/rate", authenticateToken, (req: any, res) => {
  const { rating } = req.body;
  db.prepare("UPDATE notes SET rating_sum = rating_sum + ?, rating_count = rating_count + 1 WHERE id = ?").run(rating, req.params.id);
  res.sendStatus(200);
});

app.post("/api/notes/:id/comment", authenticateToken, (req: any, res) => {
  const { text } = req.body;
  db.prepare("INSERT INTO comments (user_id, note_id, text) VALUES (?, ?, ?)").run(req.user.id, req.params.id, text);
  res.sendStatus(201);
});

// --- USER ROUTES ---
app.get("/api/profile", authenticateToken, (req: any, res) => {
  const user = db.prepare("SELECT id, name, email, role, profile_picture FROM users WHERE id = ?").get(req.user.id);
  const uploadedNotes = db.prepare("SELECT * FROM notes WHERE uploader_id = ?").all(req.user.id);
  const bookmarks = db.prepare(`
    SELECT notes.* FROM notes 
    JOIN bookmarks ON notes.id = bookmarks.note_id 
    WHERE bookmarks.user_id = ?
  `).all(req.user.id);
  
  res.json({ user, uploadedNotes, bookmarks });
});

app.post("/api/bookmarks/:id", authenticateToken, (req: any, res) => {
  try {
    db.prepare("INSERT INTO bookmarks (user_id, note_id) VALUES (?, ?)").run(req.user.id, req.params.id);
    res.sendStatus(201);
  } catch (e) {
    db.prepare("DELETE FROM bookmarks WHERE user_id = ? AND note_id = ?").run(req.user.id, req.params.id);
    res.sendStatus(200);
  }
});

// --- ADMIN ROUTES ---
app.get("/api/admin/stats", authenticateToken, (req: any, res) => {
  if (req.user.role !== "admin") return res.sendStatus(403);
  
  const totalUsers = db.prepare("SELECT COUNT(*) as count FROM users").get() as any;
  const totalNotes = db.prepare("SELECT COUNT(*) as count FROM notes").get() as any;
  const subjectStats = db.prepare("SELECT subject, COUNT(*) as count FROM notes GROUP BY subject").all();
  const topNotes = db.prepare("SELECT title, downloads FROM notes ORDER BY downloads DESC LIMIT 5").all();
  
  res.json({
    totalUsers: totalUsers.count,
    totalNotes: totalNotes.count,
    subjectStats,
    topNotes
  });
});

app.get("/api/admin/pending", authenticateToken, (req: any, res) => {
  if (req.user.role !== "admin") return res.sendStatus(403);
  const pending = db.prepare("SELECT * FROM notes WHERE is_approved = 0").all();
  res.json(pending);
});

app.post("/api/admin/approve/:id", authenticateToken, (req: any, res) => {
  if (req.user.role !== "admin") return res.sendStatus(403);
  db.prepare("UPDATE notes SET is_approved = 1 WHERE id = ?").run(req.params.id);
  res.sendStatus(200);
});

// AI Update Route (to be called from frontend after upload)
app.post("/api/notes/:id/ai", authenticateToken, (req: any, res) => {
  const { summary, keywords } = req.body;
  db.prepare("UPDATE notes SET ai_summary = ?, ai_keywords = ? WHERE id = ?").run(summary, keywords, req.params.id);
  res.sendStatus(200);
});

// Vite Integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
