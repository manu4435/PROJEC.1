import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { BookOpen, User, LogOut, LayoutDashboard, Upload, Shield } from 'lucide-react';

const Navbar: React.FC = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  return (
    <nav className="fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md border-b border-zinc-200 z-50 px-6 flex items-center justify-between">
      <Link to="/" className="flex items-center gap-2 font-bold text-xl text-indigo-600">
        <BookOpen className="w-8 h-8" />
        <span>NoteShare Pro</span>
      </Link>

      <div className="flex items-center gap-6">
        {isAuthenticated ? (
          <>
            <Link to="/dashboard" className="text-zinc-600 hover:text-indigo-600 flex items-center gap-1">
              <LayoutDashboard className="w-4 h-4" />
              Dashboard
            </Link>
            <Link to="/upload" className="text-zinc-600 hover:text-indigo-600 flex items-center gap-1">
              <Upload className="w-4 h-4" />
              Upload
            </Link>
            {user?.role === 'admin' && (
              <Link to="/admin" className="text-zinc-600 hover:text-indigo-600 flex items-center gap-1">
                <Shield className="w-4 h-4" />
                Admin
              </Link>
            )}
            <div className="h-6 w-px bg-zinc-200" />
            <Link to="/profile" className="flex items-center gap-2 text-zinc-700 font-medium">
              <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600">
                <User className="w-5 h-5" />
              </div>
              {user?.name}
            </Link>
            <button
              onClick={() => { logout(); navigate('/'); }}
              className="text-zinc-400 hover:text-red-500 transition-colors"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="text-zinc-600 hover:text-indigo-600 font-medium">Login</Link>
            <Link to="/register" className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors">
              Get Started
            </Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
