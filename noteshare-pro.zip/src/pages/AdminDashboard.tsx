import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { Note, User } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Users, FileText, CheckCircle, TrendingUp } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { token, user } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [pending, setPending] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.role !== 'admin') return;
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [statsRes, pendingRes] = await Promise.all([
        axios.get('/api/admin/stats', { headers: { Authorization: `Bearer ${token}` } }),
        axios.get('/api/admin/pending', { headers: { Authorization: `Bearer ${token}` } })
      ]);
      setStats(statsRes.data);
      setPending(pendingRes.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const approveNote = async (id: number) => {
    try {
      await axios.post(`/api/admin/approve/${id}`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  if (user?.role !== 'admin') return <div className="pt-32 text-center">Unauthorized</div>;
  if (loading) return <div className="pt-32 text-center">Loading...</div>;

  const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="pt-24 px-6 max-w-7xl mx-auto pb-24">
      <h1 className="text-3xl font-bold text-zinc-900 mb-8">Admin Control Panel</h1>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
        <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
              <Users className="w-6 h-6" />
            </div>
            <span className="text-zinc-500 font-medium">Total Users</span>
          </div>
          <div className="text-3xl font-bold text-zinc-900">{stats.totalUsers}</div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
              <FileText className="w-6 h-6" />
            </div>
            <span className="text-zinc-500 font-medium">Total Notes</span>
          </div>
          <div className="text-3xl font-bold text-zinc-900">{stats.totalNotes}</div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
              <CheckCircle className="w-6 h-6" />
            </div>
            <span className="text-zinc-500 font-medium">Pending Approval</span>
          </div>
          <div className="text-3xl font-bold text-zinc-900">{pending.length}</div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-rose-50 text-rose-600 rounded-2xl">
              <TrendingUp className="w-6 h-6" />
            </div>
            <span className="text-zinc-500 font-medium">Growth</span>
          </div>
          <div className="text-3xl font-bold text-zinc-900">+12%</div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
          <h3 className="text-xl font-bold text-zinc-900 mb-6">Subject Popularity</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.subjectStats}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="subject" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip />
                <Bar dataKey="count" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
          <h3 className="text-xl font-bold text-zinc-900 mb-6">Distribution</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.subjectStats}
                  dataKey="count"
                  nameKey="subject"
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  label
                >
                  {stats.subjectStats.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Pending Approvals */}
      <div className="bg-white border border-zinc-200 rounded-3xl shadow-sm overflow-hidden">
        <div className="p-8 border-b border-zinc-100">
          <h3 className="text-2xl font-bold text-zinc-900">Pending Approvals</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-zinc-50 text-zinc-500 text-sm uppercase tracking-wider">
              <tr>
                <th className="px-8 py-4 font-bold">Title</th>
                <th className="px-8 py-4 font-bold">Subject</th>
                <th className="px-8 py-4 font-bold">Date</th>
                <th className="px-8 py-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {pending.map(note => (
                <tr key={note.id} className="hover:bg-zinc-50 transition-colors">
                  <td className="px-8 py-4 font-medium text-zinc-900">{note.title}</td>
                  <td className="px-8 py-4 text-zinc-600">{note.subject}</td>
                  <td className="px-8 py-4 text-zinc-400">{new Date(note.created_at).toLocaleDateString()}</td>
                  <td className="px-8 py-4 text-right">
                    <button 
                      onClick={() => approveNote(note.id)}
                      className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-indigo-700 transition-all"
                    >
                      Approve
                    </button>
                  </td>
                </tr>
              ))}
              {pending.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-8 py-12 text-center text-zinc-400">
                    No pending notes to review.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
