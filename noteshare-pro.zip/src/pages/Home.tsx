import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Note } from '../types';
import { Search, Filter, BookOpen, Download, Star, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

const Home: React.FC = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [search, setSearch] = useState('');
  const [subject, setSubject] = useState('');
  const [loading, setLoading] = useState(true);

  const subjects = ['Computer Science', 'Mathematics', 'Engineering', 'Biology', 'Physics', 'Chemistry', 'Business'];

  useEffect(() => {
    fetchNotes();
  }, [subject]);

  const fetchNotes = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`/api/notes?subject=${subject}&search=${search}`);
      setNotes(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-24 px-6 max-w-7xl mx-auto pb-12">
      {/* Hero */}
      <div className="text-center mb-16">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl font-bold text-zinc-900 mb-4 tracking-tight"
        >
          Share Knowledge, <span className="text-indigo-600">Succeed Together</span>
        </motion.h1>
        <p className="text-zinc-500 text-lg max-w-2xl mx-auto">
          The ultimate platform for students to share high-quality study notes, powered by AI summaries and a vibrant community.
        </p>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-4 mb-12">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search notes by title or description..."
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-zinc-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchNotes()}
          />
        </div>
        <select
          className="px-4 py-3 rounded-xl border border-zinc-200 focus:ring-2 focus:ring-indigo-500 outline-none bg-white min-w-[200px]"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        >
          <option value="">All Subjects</option>
          {subjects.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <button 
          onClick={fetchNotes}
          className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-medium hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
        >
          <Filter className="w-5 h-5" />
          Search
        </button>
      </div>

      {/* Notes Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-64 bg-zinc-100 rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {notes.map((note) => (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              key={note.id}
              className="group bg-white border border-zinc-200 rounded-2xl p-6 hover:shadow-xl hover:border-indigo-200 transition-all cursor-pointer"
            >
              <Link to={`/notes/${note.id}`}>
                <div className="flex items-start justify-between mb-4">
                  <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <div className="flex items-center gap-1 text-amber-500 font-medium">
                    <Star className="w-4 h-4 fill-amber-500" />
                    {note.rating_count > 0 ? (note.rating_sum / note.rating_count).toFixed(1) : 'N/A'}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-zinc-900 mb-2 group-hover:text-indigo-600 transition-colors line-clamp-1">
                  {note.title}
                </h3>
                <p className="text-zinc-500 text-sm mb-4 line-clamp-2">
                  {note.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  <span className="px-2 py-1 bg-zinc-100 text-zinc-600 text-xs font-medium rounded-md">
                    {note.subject}
                  </span>
                  {note.tags?.split(',').map(tag => (
                    <span key={tag} className="px-2 py-1 bg-indigo-50 text-indigo-600 text-xs font-medium rounded-md">
                      #{tag.trim()}
                    </span>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-zinc-100">
                  <div className="flex items-center gap-2 text-zinc-400 text-xs">
                    <Clock className="w-4 h-4" />
                    {new Date(note.created_at).toLocaleDateString()}
                  </div>
                  <div className="flex items-center gap-1 text-zinc-600 text-sm font-medium">
                    <Download className="w-4 h-4" />
                    {note.downloads}
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}

      {!loading && notes.length === 0 && (
        <div className="text-center py-24">
          <p className="text-zinc-400 text-lg">No notes found matching your criteria.</p>
        </div>
      )}
    </div>
  );
};

export default Home;
