import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Upload, FileText, CheckCircle2, Loader2, Sparkles } from 'lucide-react';
import { summarizeNote } from '../services/geminiService';

const UploadNote: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    subject: 'Computer Science',
    tags: ''
  });
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  const { token } = useAuth();
  const navigate = useNavigate();

  const subjects = ['Computer Science', 'Mathematics', 'Engineering', 'Biology', 'Physics', 'Chemistry', 'Business'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setLoading(true);
    const data = new FormData();
    data.append('file', file);
    data.append('title', formData.title);
    data.append('description', formData.description);
    data.append('subject', formData.subject);
    data.append('tags', formData.tags);

    try {
      const res = await axios.post('/api/notes', data, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const noteId = res.data.id;
      setStep(2);

      // AI Summary
      try {
        const aiResult = await summarizeNote(formData.title, formData.description, "Note content preview...");
        if (aiResult) {
          await axios.post(`/api/notes/${noteId}/ai`, {
            summary: aiResult.summary,
            keywords: aiResult.keywords.join(', ')
          }, {
            headers: { Authorization: `Bearer ${token}` }
          });
        }
      } catch (aiError) {
        console.error("AI processing failed", aiError);
      }

      setStep(3);
      setTimeout(() => navigate('/dashboard'), 2000);
    } catch (e) {
      console.error(e);
      alert('Upload failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-24 px-6 max-w-3xl mx-auto pb-12">
      <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
        <h1 className="text-3xl font-bold text-zinc-900 mb-8">Upload Study Notes</h1>

        {step === 1 && (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-zinc-700">Note Title</label>
              <input
                required
                type="text"
                className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="e.g. Data Structures - Week 4"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-zinc-700">Subject</label>
                <select
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:ring-2 focus:ring-indigo-500 outline-none bg-white"
                  value={formData.subject}
                  onChange={e => setFormData({ ...formData, subject: e.target.value })}
                >
                  {subjects.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-zinc-700">Tags (comma separated)</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="algorithms, java, sorting"
                  value={formData.tags}
                  onChange={e => setFormData({ ...formData, tags: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-zinc-700">Description</label>
              <textarea
                className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:ring-2 focus:ring-indigo-500 outline-none min-h-[120px]"
                placeholder="What are these notes about?"
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-zinc-700">PDF File</label>
              <div className="relative border-2 border-dashed border-zinc-200 rounded-2xl p-8 text-center hover:border-indigo-500 transition-colors cursor-pointer group">
                <input
                  required
                  type="file"
                  accept=".pdf"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  onChange={e => setFile(e.target.files?.[0] || null)}
                />
                <div className="flex flex-col items-center gap-2">
                  <div className="p-4 bg-zinc-50 text-zinc-400 rounded-full group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                    <FileText className="w-8 h-8" />
                  </div>
                  <p className="text-zinc-600 font-medium">
                    {file ? file.name : 'Click or drag PDF here to upload'}
                  </p>
                  <p className="text-zinc-400 text-xs">Maximum file size: 10MB</p>
                </div>
              </div>
            </div>

            <button
              disabled={loading}
              type="submit"
              className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
              Upload and Process
            </button>
          </form>
        )}

        {step === 2 && (
          <div className="py-12 text-center space-y-6">
            <div className="relative inline-block">
              <Sparkles className="w-16 h-16 text-indigo-500 animate-pulse" />
            </div>
            <h2 className="text-2xl font-bold text-zinc-900">AI is analyzing your notes...</h2>
            <p className="text-zinc-500">Generating automatic summary and keywords for better searchability.</p>
            <div className="w-full bg-zinc-100 h-2 rounded-full overflow-hidden">
              <div className="bg-indigo-600 h-full w-2/3 animate-[progress_2s_ease-in-out_infinite]" />
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="py-12 text-center space-y-4">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full mb-4">
              <CheckCircle2 className="w-12 h-12" />
            </div>
            <h2 className="text-2xl font-bold text-zinc-900">Upload Successful!</h2>
            <p className="text-zinc-500">Your notes have been submitted for approval. Redirecting to dashboard...</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default UploadNote;
