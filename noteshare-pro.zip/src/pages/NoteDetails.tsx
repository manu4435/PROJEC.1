import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Note, Comment } from '../types';
import { useAuth } from '../context/AuthContext';
import { Download, Star, MessageSquare, User, Calendar, Tag, Sparkles, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

const NoteDetails: React.FC = () => {
  const { id } = useParams();
  const { token, user } = useAuth();
  const [note, setNote] = useState<Note | null>(null);
  const [commentText, setCommentText] = useState('');
  const [rating, setRating] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNote();
  }, [id]);

  const fetchNote = async () => {
    try {
      const res = await axios.get(`/api/notes/${id}`);
      setNote(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!note) return;
    try {
      await axios.post(`/api/notes/${id}/download`);
      window.open(`/${note.file_path}`, '_blank');
      fetchNote();
    } catch (e) {
      console.error(e);
    }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    try {
      await axios.post(`/api/notes/${id}/comment`, { text: commentText }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCommentText('');
      fetchNote();
    } catch (e) {
      console.error(e);
    }
  };

  const handleRate = async (val: number) => {
    try {
      await axios.post(`/api/notes/${id}/rate`, { rating: val }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRating(val);
      fetchNote();
    } catch (e) {
      console.error(e);
    }
  };

  const handleBookmark = async () => {
    try {
      await axios.post(`/api/bookmarks/${id}`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Bookmark updated!');
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) return <div className="pt-32 text-center">Loading...</div>;
  if (!note) return <div className="pt-32 text-center">Note not found</div>;

  return (
    <div className="pt-24 px-6 max-w-7xl mx-auto pb-24">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <span className="px-3 py-1 bg-indigo-50 text-indigo-600 text-sm font-bold rounded-full">
                {note.subject}
              </span>
              <div className="flex items-center gap-4">
                <button onClick={handleBookmark} className="text-zinc-400 hover:text-indigo-600 transition-colors">
                  <Star className="w-6 h-6" />
                </button>
                <button 
                  onClick={handleDownload}
                  className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center gap-2"
                >
                  <Download className="w-5 h-5" />
                  Download PDF
                </button>
              </div>
            </div>

            <h1 className="text-4xl font-bold text-zinc-900 mb-4">{note.title}</h1>
            <p className="text-zinc-600 text-lg mb-8 leading-relaxed">{note.description}</p>

            {/* AI Summary Section */}
            {note.ai_summary && (
              <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-6 mb-8">
                <div className="flex items-center gap-2 text-indigo-600 font-bold mb-3">
                  <Sparkles className="w-5 h-5" />
                  AI Generated Summary
                </div>
                <p className="text-zinc-700 leading-relaxed italic">"{note.ai_summary}"</p>
                <div className="flex flex-wrap gap-2 mt-4">
                  {note.ai_keywords?.split(',').map(kw => (
                    <span key={kw} className="text-xs bg-white text-indigo-500 px-2 py-1 rounded-md border border-indigo-100 font-medium">
                      {kw.trim()}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="flex flex-wrap gap-6 text-zinc-500 text-sm border-t border-zinc-100 pt-6">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                Uploaded by <span className="font-bold text-zinc-900">{note.uploader_name}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                {new Date(note.created_at).toLocaleDateString()}
              </div>
              <div className="flex items-center gap-2">
                <Download className="w-4 h-4" />
                {note.downloads} Downloads
              </div>
            </div>
          </div>

          {/* Comments */}
          <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
            <h3 className="text-2xl font-bold text-zinc-900 mb-6 flex items-center gap-2">
              <MessageSquare className="w-6 h-6 text-indigo-600" />
              Community Discussion
            </h3>

            <form onSubmit={handleComment} className="mb-8">
              <textarea
                className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:ring-2 focus:ring-indigo-500 outline-none min-h-[100px] mb-3"
                placeholder="Share your thoughts or ask a question..."
                value={commentText}
                onChange={e => setCommentText(e.target.value)}
              />
              <button className="bg-zinc-900 text-white px-6 py-2 rounded-xl font-bold hover:bg-zinc-800 transition-all">
                Post Comment
              </button>
            </form>

            <div className="space-y-6">
              {note.comments?.map((c: any) => (
                <div key={c.id} className="flex gap-4">
                  <div className="w-10 h-10 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-400 shrink-0">
                    <User className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-zinc-900">{c.user_name}</span>
                      <span className="text-xs text-zinc-400">{new Date(c.created_at).toLocaleDateString()}</span>
                    </div>
                    <p className="text-zinc-600">{c.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-8">
          <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
            <h4 className="font-bold text-zinc-900 mb-4">Rate this Note</h4>
            <div className="flex gap-2 mb-4">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  onClick={() => handleRate(star)}
                  className={`p-1 transition-colors ${rating >= star ? 'text-amber-500' : 'text-zinc-200'}`}
                >
                  <Star className={`w-8 h-8 ${rating >= star ? 'fill-amber-500' : ''}`} />
                </button>
              ))}
            </div>
            <p className="text-sm text-zinc-500">
              Average Rating: <span className="font-bold text-zinc-900">
                {note.rating_count > 0 ? (note.rating_sum / note.rating_count).toFixed(1) : 'No ratings yet'}
              </span>
            </p>
          </div>

          <div className="bg-zinc-900 text-white rounded-3xl p-8 shadow-sm">
            <h4 className="font-bold mb-4 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-indigo-400" />
              Safety & Quality
            </h4>
            <p className="text-zinc-400 text-sm leading-relaxed mb-6">
              All notes are reviewed by our community and AI to ensure accuracy and academic integrity.
            </p>
            <button className="text-indigo-400 text-sm font-bold hover:underline">
              Report Inappropriate Content
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NoteDetails;
