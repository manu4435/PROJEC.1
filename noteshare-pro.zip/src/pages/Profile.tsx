import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { User as UserType } from '../types';
import { User as UserIcon, Camera, Mail, Shield, Calendar, Loader2, Save } from 'lucide-react';
import { motion } from 'motion/react';

const Profile: React.FC = () => {
  const { token, user: authUser } = useAuth();
  const [user, setUser] = useState<UserType | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const res = await axios.get('/api/profile', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUser(res.data.user);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="pt-32 text-center">Loading...</div>;
  if (!user) return <div className="pt-32 text-center">Error loading profile</div>;

  return (
    <div className="pt-24 px-6 max-w-4xl mx-auto pb-24">
      <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
        {/* Header */}
        <div className="h-32 bg-indigo-600 relative">
          <div className="absolute -bottom-12 left-8">
            <div className="relative group">
              <div className="w-24 h-24 rounded-3xl bg-white p-1 shadow-lg">
                <div className="w-full h-full rounded-2xl bg-zinc-100 flex items-center justify-center text-zinc-400">
                  <UserIcon className="w-12 h-12" />
                </div>
              </div>
              <button className="absolute bottom-0 right-0 p-2 bg-white rounded-xl shadow-md border border-zinc-100 text-zinc-600 hover:text-indigo-600 transition-colors">
                <Camera className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="pt-16 px-8 pb-8">
          <div className="flex items-start justify-between mb-12">
            <div>
              <h1 className="text-3xl font-bold text-zinc-900">{user.name}</h1>
              <p className="text-zinc-500 flex items-center gap-2 mt-1">
                <Mail className="w-4 h-4" />
                {user.email}
              </p>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl font-bold text-sm">
              <Shield className="w-4 h-4" />
              {user.role.toUpperCase()}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <h3 className="text-lg font-bold text-zinc-900 border-b border-zinc-100 pb-2">Personal Information</h3>
              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-zinc-400 uppercase">Full Name</label>
                  <input 
                    type="text" 
                    defaultValue={user.name}
                    className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-zinc-400 uppercase">Email Address</label>
                  <input 
                    disabled
                    type="email" 
                    defaultValue={user.email}
                    className="w-full px-4 py-3 rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-400 cursor-not-allowed"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-lg font-bold text-zinc-900 border-b border-zinc-100 pb-2">Account Settings</h3>
              <div className="space-y-4">
                <div className="p-4 bg-zinc-50 rounded-2xl flex items-center justify-between">
                  <div>
                    <p className="font-bold text-zinc-900 text-sm">Two-Factor Authentication</p>
                    <p className="text-xs text-zinc-500">Add an extra layer of security</p>
                  </div>
                  <div className="w-10 h-5 bg-zinc-200 rounded-full relative cursor-pointer">
                    <div className="absolute left-1 top-1 w-3 h-3 bg-white rounded-full" />
                  </div>
                </div>
                <div className="p-4 bg-zinc-50 rounded-2xl flex items-center justify-between">
                  <div>
                    <p className="font-bold text-zinc-900 text-sm">Public Profile</p>
                    <p className="text-xs text-zinc-500">Allow others to see your uploads</p>
                  </div>
                  <div className="w-10 h-5 bg-indigo-600 rounded-full relative cursor-pointer">
                    <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-zinc-100 flex justify-end">
            <button 
              disabled={saving}
              className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center gap-2 disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
