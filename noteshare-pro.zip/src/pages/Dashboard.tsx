import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { Note, User } from '../types';
import { Link } from 'react-router-dom';
import { LayoutDashboard, FileText, Bookmark, Clock, ArrowRight, BookOpen, Star } from 'lucide-react';
import { motion } from 'motion/react';

const Dashboard: React.FC = () => {
  const { token } = useAuth();
  const [data, setData] = useState<{ user: User, uploadedNotes: Note[], bookmarks: Note[] } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const res = await axios.get('/api/profile', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setData(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="pt-32 text-center">Loading...</div>;
  if (!data) return <div className="pt-32 text-center">Error loading dashboard</div>;

  return (
    <div className="pt-24 px-6 max-w-7xl mx-auto pb-24">
      <div className="flex items-center justify-between mb-12">
        <div>
          <h1 className="text-4xl font-bold text-zinc-900 mb-2">Welcome back, {data.user.name}!</h1>
          <p className="text-zinc-500">Track your contributions and saved study materials.</p>
        </div>
        <Link 
          to="/upload" 
          className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center gap-2"
        >
          Upload New Notes
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Stats */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white border border-zinc-200 rounded-3xl p-8 shadow-sm">
            <h3 className="text-lg font-bold text-zinc-900 mb-6 flex items-center gap-2">
              <LayoutDashboard className="w-5 h-5 text-indigo-600" />
              Your Stats
            </h3>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-zinc-500">Notes Uploaded</span>
                <span className="text-2xl font-bold text-zinc-900">{data.uploadedNotes.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-500">Total Downloads</span>
                <span className="text-2xl font-bold text-zinc-900">
                  {data.uploadedNotes.reduce((acc, n) => acc + n.downloads, 0)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-500">Saved Notes</span>
                <span className="text-2xl font-bold text-zinc-900">{data.bookmarks.length}</span>
              </div>
            </div>
          </div>

          <div className="bg-indigo-600 text-white rounded-3xl p-8 shadow-sm">
            <h3 className="text-lg font-bold mb-4">Pro Tip</h3>
            <p className="text-indigo-100 text-sm leading-relaxed">
              Notes with clear descriptions and relevant tags get 3x more downloads. Use AI to generate summaries for better visibility!
            </p>
          </div>
        </div>

        {/* Lists */}
        <div className="lg:col-span-2 space-y-8">
          {/* Uploaded Notes */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-zinc-900 flex items-center gap-2">
                <FileText className="w-6 h-6 text-indigo-600" />
                Your Uploads
              </h3>
            </div>
            <div className="space-y-4">
              {data.uploadedNotes.map(note => (
                <Link 
                  to={`/notes/${note.id}`} 
                  key={note.id}
                  className="flex items-center justify-between p-6 bg-white border border-zinc-200 rounded-2xl hover:border-indigo-500 transition-all group"
                >
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-zinc-50 text-zinc-400 rounded-xl group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                      <BookOpen className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-zinc-900 group-hover:text-indigo-600 transition-colors">{note.title}</h4>
                      <div className="flex items-center gap-4 text-xs text-zinc-400 mt-1">
                        <span>{note.subject}</span>
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(note.created_at).toLocaleDateString()}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${note.is_approved ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                          {note.is_approved ? 'Approved' : 'Pending'}
                        </span>
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-zinc-300 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
                </Link>
              ))}
              {data.uploadedNotes.length === 0 && (
                <div className="text-center py-12 bg-zinc-50 rounded-2xl border-2 border-dashed border-zinc-200">
                  <p className="text-zinc-400">You haven't uploaded any notes yet.</p>
                </div>
              )}
            </div>
          </section>

          {/* Bookmarks */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-zinc-900 flex items-center gap-2">
                <Bookmark className="w-6 h-6 text-indigo-600" />
                Saved for Later
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {data.bookmarks.map(note => (
                <Link 
                  to={`/notes/${note.id}`} 
                  key={note.id}
                  className="p-6 bg-white border border-zinc-200 rounded-2xl hover:border-indigo-500 transition-all group"
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md">{note.subject}</span>
                    <div className="flex items-center gap-1 text-amber-500 text-xs font-bold">
                      <Star className="w-3 h-3 fill-amber-500" />
                      {note.rating_count > 0 ? (note.rating_sum / note.rating_count).toFixed(1) : 'N/A'}
                    </div>
                  </div>
                  <h4 className="font-bold text-zinc-900 group-hover:text-indigo-600 transition-colors line-clamp-1 mb-2">{note.title}</h4>
                  <p className="text-zinc-500 text-xs line-clamp-2 mb-4">{note.description}</p>
                  <div className="flex items-center justify-between text-[10px] text-zinc-400 pt-4 border-t border-zinc-100">
                    <span>By {note.uploader_name}</span>
                    <span>{note.downloads} downloads</span>
                  </div>
                </Link>
              ))}
              {data.bookmarks.length === 0 && (
                <div className="col-span-2 text-center py-12 bg-zinc-50 rounded-2xl border-2 border-dashed border-zinc-200">
                  <p className="text-zinc-400">Your saved library is empty.</p>
                </div>
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
