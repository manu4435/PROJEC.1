import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function summarizeNote(title: string, description: string, contentPreview: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Summarize these study notes. Title: ${title}. Description: ${description}. Content Snippet: ${contentPreview}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            studyTips: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["summary", "keywords", "studyTips"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("AI Summarization failed:", error);
    return null;
  }
}
