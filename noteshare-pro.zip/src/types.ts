export interface User {
  id: number;
  name: string;
  email: string;
  role: 'student' | 'admin';
  profile_picture?: string;
}

export interface Note {
  id: number;
  title: string;
  description: string;
  subject: string;
  tags: string;
  file_path: string;
  uploader_id: number;
  uploader_name: string;
  downloads: number;
  rating_sum: number;
  rating_count: number;
  is_approved: boolean;
  ai_summary?: string;
  ai_keywords?: string;
  created_at: string;
  comments?: Comment[];
}

export interface Comment {
  id: number;
  user_id: number;
  user_name: string;
  text: string;
  created_at: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}
